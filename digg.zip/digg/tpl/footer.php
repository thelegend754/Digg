<footer class="bg-primary p-2">
  <div class="container-fluid">
    <div class="row">
      <div class="col-12 text-center">
        <p class="text-white">Digg &copy; <?= date('Y'); ?></p>
      </div>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous">
</script>
<script src="js/script.js"></script>
</body>

</html>